<?php

/**
* Author : https://www.roytuts.com
*/

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Methods: GET");
 
           
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    if (isset($_FILES['file']['name'])) {
        if (0 < $_FILES['file']['error']) {
            echo 'Error during file upload ' . $_FILES['file']['error'];
        } else {
            $upload_path = 'uploads/';
            if (file_exists($upload_path . $_FILES['file']['name'])) {
                //echo 'File already exists => ' . $upload_path . $_FILES['file']['name'];
     $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "fileupload";
                  // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
               $filrname =  $_FILES['file']['name'];

          

            $sql = "INSERT INTO file (filename)
            VALUES ('$filrname')";

            if ($conn->query($sql) === TRUE) {
                echo json_encode(array('success' => 1 ,'msg'=>'File uploaded successfully'));
            } else {
                   echo json_encode(array('success' => 0 ,'msg'=> $conn->error)); 
            }

            $conn->close();
             
            } else {
                if (!file_exists($upload_path)) {
                    mkdir($upload_path, 0777, true);
                }
                move_uploaded_file($_FILES['file']['tmp_name'], $upload_path . $_FILES['file']['name']);
                  $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "fileupload";
                  // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
               $filrname =  $_FILES['file']['name'];

          

            $sql = "INSERT INTO file (filename)
            VALUES ('$filrname')";

            if ($conn->query($sql) === TRUE) {
               // echo json_encode(array('success' => 1 ,'msg'=>'File uploaded successfully'));
            } else {
                 //  echo json_encode(array('success' => 0 ,'msg'=> $conn->error)); 
            }

            $conn->close();
                echo 'File successfully uploaded ';
            }
        }
    } else {
        echo 'Please choose a file';
    }
   // echo nl2br("\n");

}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // print_r($_FILES); 
//print_r($_POST);
//die();

    $search =$_POST['files'];
                 $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "fileupload";
                  // Create connection
           // $conn = new mysqli($servername, $username, $password, $dbname);echo $query2 = "SELECT id, filename FROM file where filename '%$search%'";
  $connection = mysqli_connect("localhost","root","","fileupload") or die("Error " . mysqli_error($connection));
 
    //fetch table rows from mysql db
    $sql = "SELECT id, filename FROM file where filename like '%$search%'";
    $result = mysqli_query($connection, $sql) or die("Error in Selecting " . mysqli_error($connection));
 
    //create an array
    $emptyarray = array();
    while($row =mysqli_fetch_assoc($result))
    {
        $emptyarray[] = $row;
    }
     //header('Content-type: application/json');
    echo json_encode($emptyarray);
 
    //close the db connection
    }