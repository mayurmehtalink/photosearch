import { Component , ElementRef, ViewChild } from '@angular/core';
import { PhpserveService } from './phpserve.service';
import { HttpResponse, HttpEventType } from '@angular/common/http'; 
import { UploadService } from './upload.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'photosearch';
    private toggle : boolean = false;
  @ViewChild('search') search:ElementRef;
 constructor(private fileService: UploadService,public backendService: PhpserveService) {}

viewImage(event: Event){
      


  var elems = document.querySelectorAll(".border");
  [].forEach.call(elems, function(el) {
    el.classList.remove("border");
  });
  event.target.setAttribute("class", "border");


}
zoom(event: Event) {
var elems = document.querySelectorAll(".border");
if(event.target.value == 'large' && event.target.value == 'small'){
alert('Select Image');
}
if(event.target.value == 'large'){
  [].forEach.call(elems, function(el) {
  
        el.classList.add('zoom');
    
  });
 
}
if(event.target.value == 'small'){
  [].forEach.call(elems, function(el) {
  
        el.classList.remove('zoom');
    
  });

}
console.log(event.target.value);
}
  handleClick(event: Event) {
  this.backendService.get().subscribe();
   const searchs = this.search.nativeElement.value
    this.fileService.getFile(searchs).subscribe(response => {
	
     if (response instanceof HttpResponse) {
	
        console.log(response.body);
        this.msg =JSON.parse(response.body);
      }	  
    });  
  console.log('Click!', searchs)
}
}
