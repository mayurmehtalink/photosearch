import { TestBed } from '@angular/core/testing';

import { PhpserveService } from './phpserve.service';

describe('PhpserveService', () => {
  let service: PhpserveService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PhpserveService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
