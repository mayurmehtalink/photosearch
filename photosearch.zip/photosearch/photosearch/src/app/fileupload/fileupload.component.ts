import { Component, OnInit } from '@angular/core';
import { UploadService } from '../upload.service';
import { HttpResponse, HttpEventType } from '@angular/common/http'; 
@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.css']
})
export class FileuploadComponent  {

 selectedFiles: FileList;
	currentFile: File;
msg:string;
    constructor(private fileService: UploadService) {}

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
  
  upload() {
    this.currentFile = this.selectedFiles.item(0);
    this.fileService.uploadFile(this.currentFile).subscribe(response => {
		this.msg ='';
     if (response instanceof HttpResponse) {
		    alert(response.body);
        console.log(response.body);
      }	  
    });    
  }
}
