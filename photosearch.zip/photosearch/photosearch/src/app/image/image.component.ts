import { Component, OnInit } from '@angular/core';
import { PhpserveService } from '../phpserve.service';
import { HttpResponse, HttpEventType } from '@angular/common/http'; 
import { UploadService } from '../upload.service';

@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent implements OnInit {

  constructor(private fileService: UploadService,public backendService: PhpserveService) { }

  ngOnInit(): void {
  }
viewImage(event: Event){
      


  var elems = document.querySelectorAll(".border");
  [].forEach.call(elems, function(el) {
    el.classList.remove("border");
  });
  event.target.setAttribute("class", "border");


}

zoom(event: Event) {
var elems = document.querySelectorAll(".border");
if(!elems){
alert('Select Image');
}
if(event.target.value == 'large'){
  [].forEach.call(elems, function(el) {
  
        el.classList.add('zoom');
    
  });
 
}
if(event.target.value == 'small'){
  [].forEach.call(elems, function(el) {
  
        el.classList.remove('zoom');
    
  });

}
console.log(event.target.value);
}

  handleClick(event: Event) {
  this.backendService.get().subscribe();
   const searchs = this.search.nativeElement.value
    this.fileService.getFile(searchs).subscribe(response => {
	
     if (response instanceof HttpResponse) {
		    alert(response.body);
        console.log(response.body);
        this.msg =JSON.parse(response.body);
      }	  
    });  
  console.log('Click!', searchs)
}
}
